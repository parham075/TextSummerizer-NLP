import setuptools
import json

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

with open('./codemeta.json', 'r') as f:
    code_setup = json.load(f)

__version__ = code_setup['version']
REPO_NAME = code_setup['name']
AUTHOR = code_setup['author']
SRC_REPO = "textSummarizer"

setuptools.setup(
    name=SRC_REPO,
    version=__version__,
    author=AUTHOR,
    description="A python package for NLP app",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url=code_setup['codeRepository'],
    keywords=code_setup['keywords'],
    project_urls={
        "Bug Tracker": f"{code_setup['codeRepository']}/issues",
    },
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src")
)
